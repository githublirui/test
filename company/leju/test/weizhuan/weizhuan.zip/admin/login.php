<?php
session_start();
require('../conn.php');
require('../functions.php');
if($_POST){
	$username=guolv(trim($_POST['username']));
	$password=guolv(trim($_POST['password']));
	$yzm=guolv(trim($_POST['yzm']));
	//print_r($row);
	if($yzm!==$_SESSION['code'] && $config['AdminLoginCode']==1){
		echo "<script>alert('验证码不正确');location.href='login.php'</script>";
		exit;
	}
	if($username!=='' & $password!==''){		
		$row=$mysql->query("select * from `admindata` where `username`='{$username}' and `password`='{$password}' limit 1");
		if($row){
			$_SESSION['admin']=1;
			$_SESSION['admindata']=$row[0];
			_location('ucenter.php',301);
			exit;
		}
	}
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap-responsive.css">
    <link rel="stylesheet" type="text/css" href="stylesheets/theme.css">
    <link rel="stylesheet" href="lib/font-awesome/css/font-awesome.css">

    <script src="lib/jquery-1.8.1.min.js" type="text/javascript"></script>

    <!-- Demo page code -->
    
    <style type="text/css">
        #line-chart {
            height:300px;
            width:800px;
            margin: 0px auto;
            margin-top: 1em;
        }
        .brand { font-family: georgia, serif; }
        .brand .first {
            color: #ccc;
            font-style: italic;
        }
        .brand .second {
            color: #fff;
            font-weight: bold;
        }
    </style>

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="../assets/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="../assets/ico/apple-touch-icon-57-precomposed.png">
  </head>

  <!--[if lt IE 7 ]> <body class="ie ie6"> <![endif]-->
  <!--[if IE 7 ]> <body class="ie ie7"> <![endif]-->
  <!--[if IE 8 ]> <body class="ie ie8"> <![endif]-->
  <!--[if IE 9 ]> <body class="ie ie9"> <![endif]-->
  <!--[if (gt IE 9)|!(IE)]><!--> 
  <body> 
  <!--<![endif]-->
    
    <div class="navbar">
        <div class="navbar-inner">
            <div class="container-fluid">
                <ul class="nav pull-right">
                    
                </ul>
<a class="brand" href="#"><span class="second">管理系统</span></a>
            </div>
        </div>
    </div>
    

    <div class="container-fluid">
        
        <div class="row-fluid">
    <div class="dialog span4">
        <div class="block">
            <div class="block-heading">登陆</div>
            <div class="block-body">
                <form action="" method="post">
                    <label>用户名</label>
                    <input type="text" class="span12" name="username" value="">				
                    <label>密码</label>
                    <input type="password" class="span12" name="password" value="">
					<?php
					if($config['AdminLoginCode']==1){
					?>
                    <label>验证码</label>
                    <input type="text" class="span12" name="yzm"><img src="../code.php?<?php echo rand(1,999)?>" onClick="this.src='../code.php?'+Math.random();" alt="点击刷新图片" title="点击刷新图片">			
                    <?php }?>
					<input type="submit" class="btn btn-primary pull-right"></input>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
    </div>
</div>


    

    

    

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="lib/bootstrap/js/bootstrap.js"></script>
    
    
    
    
    
    
    
    
    
    
    
    

  </body>
</html>
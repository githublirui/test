<?php
$cfg_basehost = '~baseurl~';
$cfg_soft_lang = '~dblang~';
$cfg_webname = '~webname~';
$cfg_cookie_encode = '~cookieEncode~';
$cfg_cmspath = '~cmpath~';
$cfg_upload_size = 1024000;
?>